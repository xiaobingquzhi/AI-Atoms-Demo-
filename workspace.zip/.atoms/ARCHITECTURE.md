---
last_updated: 2026-09-22T02:07:43Z
---

# Architecture Design

## System Overview
纯前端单页应用：目标输入 → 调用 OpenAI 兼容接口拆解任务 → 任务卡片增删改/完成 → 按任务生成测试用例；数据全部存 localStorage，无后端。

## Tech Stack

## Module Design
| Module | Responsibility | Key Files |
|--------|---------------|-----------|

## Tech Decisions
| Decision | Choice | Rationale |
|----------|--------|-----------|

## File Tree Plan

## Implementation Guide

